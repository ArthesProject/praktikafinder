import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api.js';
import { useToast } from '../components/Toast.jsx';
import { categories } from '../siteConfig.js';

export default function NewVacancy() {
  const nav = useNavigate();
  const toast = useToast();
  const [f, setF] = useState({ title: '', type: 'Стажировка', format: 'Офис', category: categories[0], description: '', requirements: '' });
  const [error, setError] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    try {
      await api('/vacancies', { method: 'POST', body: f });
      toast('Вакансия опубликована');
      nav('/dashboard');
    } catch (err) { setError(err.message); }
  };

  return (
    <form className="panel narrow" onSubmit={submit}>
      <h1>Новая вакансия</h1>
      <label>Название<input value={f.title} onChange={set('title')} required /></label>
      <div className="two">
        <label>Тип<select value={f.type} onChange={set('type')}><option>Стажировка</option><option>Практика</option></select></label>
        <label>Формат<select value={f.format} onChange={set('format')}><option>Офис</option><option>Гибрид</option><option>Удалённо</option></select></label>
      </div>
      <label>Направление
        <select value={f.category} onChange={set('category')}>
          {categories.map((c) => <option key={c}>{c}</option>)}
          <option>Другое</option>
        </select>
      </label>
      <label>Описание<textarea rows={5} value={f.description} onChange={set('description')} required /></label>
      <label>Требования<textarea rows={3} value={f.requirements} onChange={set('requirements')} /></label>
      {error && <p className="error">{error}</p>}
      <button className="btn">Опубликовать</button>
    </form>
  );
}
