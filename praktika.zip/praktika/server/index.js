import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import bcrypt from 'bcryptjs';
import fs from 'fs';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import path from 'path';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_FILE = path.join(__dirname, 'db.json');
const SECRET = process.env.JWT_SECRET || 'dev-secret-change-me';
const PORT = process.env.PORT || 4000;

// ---------- "база данных" ----------
const load = () => JSON.parse(fs.readFileSync(DB_FILE, 'utf8'));
const save = (db) => fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2));
const id = () => crypto.randomUUID();

if (!fs.existsSync(DB_FILE)) {
  const hash = bcrypt.hashSync('123456', 8);
  const mk = (role, name, email, extra = {}) => ({ id: id(), role, name, email, password: hash, about: '', ...extra });
  const elet = mk('company', 'Elet Capital', 'company@demo.kg', { about: 'Финтех-компания в Бишкеке' });
  const alatoo = mk('company', 'Ala-Too Digital', 'digital@demo.kg', { about: 'Веб-студия (демо-компания)' });
  const sary = mk('company', 'Sary-Chelek Soft', 'soft@demo.kg', { about: 'Разработка мобильных приложений (демо-компания)' });
  const issyk = mk('company', 'Issyk-Kul Design', 'design@demo.kg', { about: 'Дизайн и брендинг (демо-компания)' });
  const pamir = mk('company', 'Pamir Analytics', 'pamir@demo.kg', { about: 'Аналитика и финансы (демо-компания)' });
  const student = mk('student', 'Демо Студент', 'student@demo.kg', { university: 'Ала-Тоо', skills: 'React, JavaScript' });
  const day = 86400000;
  const vac = (c, title, type, format, category, description, requirements, ago) => ({
    id: id(), companyId: c.id, companyName: c.name, title, type, format, category, description, requirements,
    createdAt: new Date(Date.now() - ago * day).toISOString(),
  });
  save({
    users: [elet, alatoo, sary, issyk, pamir, student],
    vacancies: [
      vac(elet, 'Frontend-стажёр (React)', 'Стажировка', 'Офис', 'Frontend', 'Работа над интерфейсами на React вместе с командой. Вы будете верстать страницы, подключать API и учиться на код-ревью.', 'React, JavaScript, Git', 0),
      vac(elet, 'Backend-практикант (Node.js)', 'Практика', 'Гибрид', 'Backend', 'Разработка API на Node.js и Express, работа с базой данных, написание простых тестов.', 'Node.js, SQL', 1),
      vac(alatoo, 'Junior Frontend (практика)', 'Практика', 'Офис', 'Frontend', 'Вёрстка лендингов и сайтов для клиентов студии. Наставник в команде, гибкий график под учёбу.', 'HTML, CSS, JavaScript', 2),
      vac(sary, 'QA-стажёр', 'Стажировка', 'Гибрид', 'QA', 'Ручное тестирование мобильных приложений, составление тест-кейсов и баг-репортов.', 'Внимательность, базовое понимание тестирования', 3),
      vac(issyk, 'UI/UX дизайнер-стажёр', 'Стажировка', 'Удалённо', 'Дизайн', 'Подготовка макетов в Figma, участие в исследованиях пользователей, работа с дизайн-системой.', 'Figma, портфолио приветствуется', 4),
      vac(pamir, 'Стажёр-аналитик данных', 'Стажировка', 'Офис', 'Финансы', 'Сбор и анализ данных, построение отчётов в Excel и SQL для финансовых проектов.', 'Excel, основы SQL', 5),
      vac(alatoo, 'SMM и контент-практика', 'Практика', 'Гибрид', 'Маркетинг', 'Ведение социальных сетей студии, подготовка текстов и визуалов, анализ охватов.', 'Грамотная речь, Canva', 6),
      vac(sary, 'Junior Backend (Node.js)', 'Стажировка', 'Удалённо', 'Backend', 'Разработка серверной части мобильных приложений, работа с REST API.', 'JavaScript, Express', 8),
    ],
    applications: [],
  });
}

// ---------- helpers ----------
const safe = ({ password, ...u }) => u;
const sign = (u) => jwt.sign({ id: u.id }, SECRET, { expiresIn: '7d' });

const auth = (role) => (req, res, next) => {
  try {
    const token = (req.headers.authorization || '').replace('Bearer ', '');
    const payload = jwt.verify(token, SECRET);
    const user = load().users.find((u) => u.id === payload.id);
    if (!user) throw new Error('no user');
    if (role && user.role !== role) return res.status(403).json({ error: 'Нет доступа' });
    req.user = user;
    next();
  } catch {
    res.status(401).json({ error: 'Нужно войти в аккаунт' });
  }
};

const app = express();
app.use(cors());
app.use(express.json());

// ---------- auth ----------
app.post('/api/auth/register', (req, res) => {
  const { name, email, password, role } = req.body || {};
  if (!name || !email || !password) return res.status(400).json({ error: 'Заполните все поля' });
  if (password.length < 6) return res.status(400).json({ error: 'Пароль минимум 6 символов' });
  if (!['student', 'company'].includes(role)) return res.status(400).json({ error: 'Выберите роль' });
  const db = load();
  if (db.users.some((u) => u.email.toLowerCase() === email.toLowerCase()))
    return res.status(409).json({ error: 'Этот email уже зарегистрирован' });
  const user = { id: id(), role, name, email, password: bcrypt.hashSync(password, 8), about: '', skills: '', university: '' };
  db.users.push(user);
  save(db);
  res.json({ token: sign(user), user: safe(user) });
});

app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body || {};
  const user = load().users.find((u) => u.email.toLowerCase() === (email || '').toLowerCase());
  if (!user || !bcrypt.compareSync(password || '', user.password))
    return res.status(401).json({ error: 'Неверный email или пароль' });
  res.json({ token: sign(user), user: safe(user) });
});

app.get('/api/me', auth(), (req, res) => res.json(safe(req.user)));

app.put('/api/profile', auth(), (req, res) => {
  const db = load();
  const u = db.users.find((x) => x.id === req.user.id);
  for (const k of ['name', 'about', 'skills', 'university']) if (typeof req.body[k] === 'string') u[k] = req.body[k];
  save(db);
  res.json(safe(u));
});

// ---------- stats ----------
app.get('/api/stats', (req, res) => {
  const db = load();
  res.json({
    vacancies: db.vacancies.length,
    companies: db.users.filter((u) => u.role === 'company').length,
    students: db.users.filter((u) => u.role === 'student').length,
    applications: db.applications.length,
  });
});

// ---------- vacancies ----------
app.get('/api/vacancies', (req, res) => {
  const { q = '', type = '', category = '' } = req.query;
  const s = q.toLowerCase();
  const list = load()
    .vacancies.filter((v) => !type || v.type === type)
    .filter((v) => !category || v.category === category)
    .filter((v) => !s || [v.title, v.companyName, v.description, v.requirements].join(' ').toLowerCase().includes(s))
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  res.json(list);
});

app.get('/api/vacancies/:id', (req, res) => {
  const v = load().vacancies.find((x) => x.id === req.params.id);
  if (!v) return res.status(404).json({ error: 'Вакансия не найдена' });
  res.json(v);
});

app.post('/api/vacancies', auth('company'), (req, res) => {
  const { title, type, format, category, description, requirements } = req.body || {};
  if (!title || !description) return res.status(400).json({ error: 'Укажите название и описание' });
  const db = load();
  const v = {
    id: id(), companyId: req.user.id, companyName: req.user.name, title,
    type: type || 'Стажировка', format: format || 'Офис', category: category || 'Другое', description,
    requirements: requirements || '', createdAt: new Date().toISOString(),
  };
  db.vacancies.push(v);
  save(db);
  res.status(201).json(v);
});

app.delete('/api/vacancies/:id', auth('company'), (req, res) => {
  const db = load();
  const v = db.vacancies.find((x) => x.id === req.params.id);
  if (!v || v.companyId !== req.user.id) return res.status(404).json({ error: 'Вакансия не найдена' });
  db.vacancies = db.vacancies.filter((x) => x.id !== v.id);
  db.applications = db.applications.filter((a) => a.vacancyId !== v.id);
  save(db);
  res.json({ ok: true });
});

// ---------- applications ----------
app.post('/api/vacancies/:id/apply', auth('student'), (req, res) => {
  const db = load();
  const v = db.vacancies.find((x) => x.id === req.params.id);
  if (!v) return res.status(404).json({ error: 'Вакансия не найдена' });
  if (db.applications.some((a) => a.vacancyId === v.id && a.studentId === req.user.id))
    return res.status(409).json({ error: 'Вы уже откликнулись' });
  const a = { id: id(), vacancyId: v.id, studentId: req.user.id, message: (req.body?.message || '').slice(0, 1000), status: 'new', createdAt: new Date().toISOString() };
  db.applications.push(a);
  save(db);
  res.status(201).json(a);
});

app.get('/api/my/applications', auth('student'), (req, res) => {
  const db = load();
  res.json(
    db.applications.filter((a) => a.studentId === req.user.id).map((a) => ({
      ...a, vacancy: db.vacancies.find((v) => v.id === a.vacancyId) || null,
    }))
  );
});

app.get('/api/my/vacancies', auth('company'), (req, res) => {
  const db = load();
  res.json(
    db.vacancies.filter((v) => v.companyId === req.user.id).map((v) => ({
      ...v,
      applications: db.applications.filter((a) => a.vacancyId === v.id).map((a) => {
        const s = db.users.find((u) => u.id === a.studentId);
        return { ...a, student: s ? { name: s.name, email: s.email, university: s.university, skills: s.skills, about: s.about } : null };
      }),
    }))
  );
});

app.patch('/api/applications/:id', auth('company'), (req, res) => {
  const db = load();
  const a = db.applications.find((x) => x.id === req.params.id);
  const v = a && db.vacancies.find((x) => x.id === a.vacancyId);
  if (!a || v.companyId !== req.user.id) return res.status(404).json({ error: 'Отклик не найден' });
  if (!['accepted', 'rejected', 'new'].includes(req.body?.status)) return res.status(400).json({ error: 'Неверный статус' });
  a.status = req.body.status;
  save(db);
  res.json(a);
});

app.listen(PORT, () => console.log(`API: http://localhost:${PORT}`));
