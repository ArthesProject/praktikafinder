import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';

export const STATUS = { new: 'На рассмотрении', accepted: 'Принят', rejected: 'Отказ' };

export default function MyApplications() {
  const [list, setList] = useState(null);
  useEffect(() => { api('/my/applications').then(setList); }, []);
  if (!list) return <p className="muted">Загрузка…</p>;
  return (
    <>
      <h1>Мои отклики</h1>
      {list.length === 0 && <p className="muted">Вы пока никуда не откликались. <Link to="/">Посмотреть вакансии</Link></p>}
      <div className="list">
        {list.map((a) => (
          <div key={a.id} className="card">
            <div className="row">
              <h3>{a.vacancy ? <Link to={`/vacancy/${a.vacancy.id}`}>{a.vacancy.title}</Link> : 'Вакансия удалена'}</h3>
              <span className={`tag ${a.status}`}>{STATUS[a.status]}</span>
            </div>
            <p className="muted">{a.vacancy?.companyName} · {new Date(a.createdAt).toLocaleDateString('ru-RU')}</p>
          </div>
        ))}
      </div>
    </>
  );
}
