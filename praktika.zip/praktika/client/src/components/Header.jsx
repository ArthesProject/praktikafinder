import { useEffect, useRef, useState } from 'react';
import { Link, NavLink, useLocation } from 'react-router-dom';
import { useAuth } from '../auth.jsx';
import { Mark } from './Art.jsx';
import { site } from '../siteConfig.js';

export default function Header() {
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const [menu, setMenu] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const ref = useRef(null);
  const { pathname } = useLocation();

  useEffect(() => { setOpen(false); setMenu(false); }, [pathname]);

  useEffect(() => {
    const f = () => setScrolled(window.scrollY > 8);
    f();
    window.addEventListener('scroll', f, { passive: true });
    return () => window.removeEventListener('scroll', f);
  }, []);

  useEffect(() => {
    if (!menu) return;
    const h = (e) => { if (!ref.current?.contains(e.target)) setMenu(false); };
    document.addEventListener('mousedown', h);
    return () => document.removeEventListener('mousedown', h);
  }, [menu]);

  const isStudent = user.role === 'student';
  const links = [
    { to: '/', label: 'Вакансии', end: true },
    isStudent ? { to: '/applications', label: 'Мои отклики' } : { to: '/dashboard', label: 'Кабинет компании' },
    isStudent ? null : { to: '/dashboard/new', label: 'Новая вакансия' },
    { to: '/profile', label: 'Профиль' },
  ].filter(Boolean);

  return (
    <header className={`header ${scrolled ? 'scrolled' : ''}`}>
      <div className="header-in">
        <Link to="/" className="logo"><Mark size={30} />{site.name}</Link>

        <nav className={`nav ${open ? 'open' : ''}`} aria-label="Основная навигация">
          {links.map((l) => (
            <NavLink key={l.to} to={l.to} end={l.end} className="nav-link">{l.label}</NavLink>
          ))}
        </nav>

        <div className="header-right">
          <div className="user" ref={ref}>
            <button className="avatar-btn" onClick={() => setMenu(!menu)} aria-expanded={menu} aria-haspopup="menu">
              <span className="initials">{(user.name || '?')[0].toUpperCase()}</span>
              <span className="uname">{user.name.split(' ')[0]}</span>
            </button>
            {menu && (
              <div className="dropdown" role="menu">
                <div className="dd-head">
                  <strong>{user.name}</strong>
                  <div className="muted small">{isStudent ? 'Студент' : 'Компания'}</div>
                </div>
                <Link to="/profile" role="menuitem">Мой профиль</Link>
                <button onClick={logout} role="menuitem">Выйти</button>
              </div>
            )}
          </div>
          <button className={`burger ${open ? 'open' : ''}`} onClick={() => setOpen(!open)} aria-label="Меню" aria-expanded={open}>
            <span /><span /><span />
          </button>
        </div>
      </div>
      <div className="ornament" aria-hidden="true" />
    </header>
  );
}
