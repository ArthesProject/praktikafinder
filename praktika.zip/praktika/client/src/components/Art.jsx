import { useState } from 'react';

// Знак: упрощённый тундюк (верх юрты), как на флаге Кыргызстана
export function Mark({ size = 28 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden="true">
      <circle cx="16" cy="16" r="14" fill="none" stroke="currentColor" strokeWidth="2" />
      <g stroke="currentColor" strokeWidth="2" strokeLinecap="round">
        <path d="M16 2v28M4 9l24 14M4 23 28 9" />
      </g>
      <circle cx="16" cy="16" r="4.5" fill="#f2b630" stroke="currentColor" strokeWidth="2" />
    </svg>
  );
}

// Иллюстрированный портрет. hat=true — белый калпак
export function Person({ skin = '#ecc19a', hair = '#1c1a1f', shirt = '#0e7c86', hat = false, long = false, ornament = false, bg, size, x, y }) {
  return (
    <svg x={x} y={y} width={size} height={size} viewBox="0 0 120 120" aria-hidden="true">
      {bg && <rect width="120" height="120" fill={bg} />}
      {long && !hat && <path d="M33 58C28 22 50 14 60 14s32 8 27 44l3 40H30z" fill={hair} />}
      <path d="M14 120c0-26 20-36 46-36s46 10 46 36z" fill={shirt} />
      {ornament && <path d="M44 93l8 10 8-10 8 10 8-10" fill="none" stroke="#f2b630" strokeWidth="2.5" strokeLinejoin="round" />}
      <rect x="52" y="68" width="16" height="20" rx="6" fill={skin} />
      <ellipse cx="60" cy="52" rx="22" ry="25" fill={skin} />
      {!hat && <path d="M37 50c-1-20 11-27 23-27s24 7 23 27c-5-9-13-13-23-13s-18 4-23 13z" fill={hair} />}
      {hat && (
        <g>
          <path d="M38 40C38 4 82 4 82 40z" fill="#f6f3ec" />
          <path d="M35 37h50v11H35z" fill="#17171a" />
          <path d="M60 37v11" stroke="#f6f3ec" strokeWidth="2" />
          <path d="M40 42h14M66 42h14" stroke="#d7263d" strokeWidth="2" strokeLinecap="round" />
        </g>
      )}
      <path d="M47 56q4-3 8 0M65 56q4-3 8 0" fill="none" stroke="#2a2018" strokeWidth="2" strokeLinecap="round" />
      <path d="M53 67q7 5 14 0" fill="none" stroke="#9a5a43" strokeWidth="2" strokeLinecap="round" />
      <circle cx="46" cy="63" r="3.5" fill="#e59a86" opacity=".35" />
      <circle cx="74" cy="63" r="3.5" fill="#e59a86" opacity=".35" />
    </svg>
  );
}

// Главная иллюстрация: горы Ала-Тоо и студенты
export function HeroArt() {
  return (
    <svg viewBox="0 0 560 420" preserveAspectRatio="xMidYMid slice" role="img" aria-label="Студенты на фоне гор Ала-Тоо">
      <rect width="560" height="420" fill="#dff0f1" />
      <circle cx="430" cy="90" r="40" fill="#f2b630" />
      <path d="M0 300 90 190l55 55 95-115 90 120 80-80 150 130v140H0z" fill="#b9d6d9" />
      <path d="M240 130l-16 19 10-5 6 8 6-8 10 5zM90 190l-12 14 8-4 4 6 5-6 8 4z" fill="#fff" />
      <path d="M0 340 120 250l80 60 120-90 120 100 60-40 60 50v90H0z" fill="#6aa7ab" />
      <path d="M0 385c120-30 300-30 560-5v40H0z" fill="#1f5f66" />
      <Person x={50} y={225} size={195} long hair="#17151a" shirt="#284b63" skin="#e8b98f" ornament />
      <Person x={315} y={225} size={195} shirt="#f2b630" skin="#ddaa80" hair="#1a1719" />
      <Person x={165} y={185} size={235} hat shirt="#ffffff" skin="#e3b189" ornament />
    </svg>
  );
}

// Показывает настоящее фото из /public/images, а если файла нет — иллюстрацию
export function Photo({ src, alt = '', className, children }) {
  const [bad, setBad] = useState(false);
  if (!src || bad) return <div className={className}>{children}</div>;
  return <img className={className} src={src} alt={alt} onError={() => setBad(true)} />;
}
