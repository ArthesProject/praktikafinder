import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../auth.jsx';
import { useToast } from '../components/Toast.jsx';
import { Monogram, ago } from '../components/VacancyCard.jsx';

export default function Vacancy() {
  const { id } = useParams();
  const { user } = useAuth();
  const toast = useToast();
  const [v, setV] = useState(null);
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    api(`/vacancies/${id}`).then(setV).catch((e) => setError(e.message));
  }, [id]);

  const apply = async () => {
    setError('');
    try {
      await api(`/vacancies/${id}/apply`, { method: 'POST', body: { message } });
      setSent(true);
      toast('Отклик отправлен');
    } catch (e) { setError(e.message); }
  };

  if (error && !v) return <p className="error">{error}</p>;
  if (!v) return <p className="muted">Загрузка…</p>;

  return (
    <>
      <Link to="/" className="back">← Все вакансии</Link>
      <div className="detail-grid">
        <article className="detail">
          <h1>{v.title}</h1>
          <div className="tags">
            <span className="tag">{v.type}</span>
            <span className="tag plain">{v.format}</span>
            {v.category && <span className="tag plain">{v.category}</span>}
            <span className="tag plain">{ago(v.createdAt)}</span>
          </div>
          <h3>Описание</h3>
          <p className="pre">{v.description}</p>
          {v.requirements && (<><h3>Требования</h3><p className="pre">{v.requirements}</p></>)}
        </article>

        <aside className="aside">
          <div className="company">
            <Monogram name={v.companyName} size={52} />
            <div><strong>{v.companyName}</strong><div className="muted small">Бишкек</div></div>
          </div>
          {user.role === 'company' && <p className="muted">Компании не могут откликаться на вакансии.</p>}
          {user.role === 'student' && !sent && (
            <>
              <h3>Откликнуться</h3>
              <textarea rows={5} placeholder="Коротко о себе и почему вам подходит это место" value={message} onChange={(e) => setMessage(e.target.value)} />
              <button className="btn block" onClick={apply}>Отправить отклик</button>
            </>
          )}
          {sent && <p className="ok">Отклик отправлен. Статус смотрите в разделе <Link to="/applications">«Мои отклики»</Link>.</p>}
          {error && <p className="error">{error}</p>}
        </aside>
      </div>
    </>
  );
}
