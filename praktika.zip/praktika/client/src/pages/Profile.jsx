import { useState } from 'react';
import { api } from '../api.js';
import { useAuth } from '../auth.jsx';

export default function Profile() {
  const { user, setUser } = useAuth();
  const [f, setF] = useState({ name: user.name, about: user.about || '', skills: user.skills || '', university: user.university || '' });
  const [info, setInfo] = useState('');
  const [error, setError] = useState('');
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const isStudent = user.role === 'student';

  const submit = async (e) => {
    e.preventDefault();
    setInfo(''); setError('');
    try { setUser(await api('/profile', { method: 'PUT', body: f })); setInfo('Профиль сохранён'); }
    catch (err) { setError(err.message); }
  };

  return (
    <form className="panel narrow" onSubmit={submit}>
      <h1>Профиль</h1>
      <p className="muted">{user.email} · {isStudent ? 'студент' : 'компания'}</p>
      <label>{isStudent ? 'Имя и фамилия' : 'Название компании'}<input value={f.name} onChange={set('name')} required /></label>
      {isStudent && (
        <>
          <label>Университет / колледж<input value={f.university} onChange={set('university')} /></label>
          <label>Навыки<input placeholder="React, JavaScript, SQL" value={f.skills} onChange={set('skills')} /></label>
        </>
      )}
      <label>{isStudent ? 'О себе' : 'О компании'}<textarea rows={4} value={f.about} onChange={set('about')} /></label>
      {info && <p className="ok">{info}</p>}
      {error && <p className="error">{error}</p>}
      <button className="btn">Сохранить</button>
    </form>
  );
}
