import { Link } from 'react-router-dom';
import { useAuth } from '../auth.jsx';
import { Mark } from './Art.jsx';
import { site } from '../siteConfig.js';

export default function Footer() {
  const { user } = useAuth();
  const isStudent = user?.role === 'student';
  return (
    <footer className="footer">
      <div className="ornament" aria-hidden="true" />
      <div className="footer-in">
        <div>
          <Link to="/" className="logo"><Mark size={28} />{site.name}</Link>
          <p className="footer-about">{site.about}</p>
        </div>
        <div>
          <h4>Навигация</h4>
          <Link to="/">Вакансии</Link>
          <Link to={isStudent ? '/applications' : '/dashboard'}>{isStudent ? 'Мои отклики' : 'Кабинет компании'}</Link>
          <Link to="/profile">Профиль</Link>
        </div>
        <div>
          <h4>Контакты</h4>
          <a href={`mailto:${site.email}`}>{site.email}</a>
          <a href="#" onClick={(e) => e.preventDefault()}>{site.phone}</a>
          <span className="footer-line">{site.city}</span>
        </div>
        <div>
          <h4>Мы в соцсетях</h4>
          {site.socials.map((s) => (
            <a key={s.label} href={s.href} onClick={s.href === '#' ? (e) => e.preventDefault() : undefined}>{s.label}</a>
          ))}
        </div>
      </div>
      <div className="footer-bottom">
        <span>© {new Date().getFullYear()} {site.name}</span>
        <span>{site.credit}</span>
      </div>
    </footer>
  );
}
