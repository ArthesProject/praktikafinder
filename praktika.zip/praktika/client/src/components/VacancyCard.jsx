import { Link } from 'react-router-dom';

const COLORS = ['#0e7c86', '#284b63', '#a8432f', '#6b6a2a', '#3f6b4a', '#6a4c93'];
export const monoColor = (name = '') => {
  let h = 0;
  for (const c of name) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return COLORS[h % COLORS.length];
};

export function Monogram({ name, size = 46 }) {
  return (
    <span className="mono" style={{ background: monoColor(name), width: size, height: size, fontSize: size * 0.42 }}>
      {(name || '?').trim()[0].toUpperCase()}
    </span>
  );
}

export const ago = (iso) => {
  const d = Math.floor((Date.now() - new Date(iso)) / 86400000);
  if (d <= 0) return 'сегодня';
  if (d === 1) return 'вчера';
  return `${d} дн. назад`;
};

export default function VacancyCard({ v }) {
  return (
    <Link to={`/vacancy/${v.id}`} className="vcard">
      <Monogram name={v.companyName} />
      <div className="vbody">
        <h3>{v.title}</h3>
        <p className="vmeta"><span>{v.companyName}</span><span>{ago(v.createdAt)}</span></p>
        <p className="vdesc">{v.description}</p>
        <div className="tags">
          <span className="tag">{v.type}</span>
          <span className="tag plain">{v.format}</span>
          {v.category && <span className="tag plain">{v.category}</span>}
        </div>
      </div>
    </Link>
  );
}
