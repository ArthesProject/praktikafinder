import { createContext, useCallback, useContext, useState } from 'react';

const T = createContext(() => {});
export const useToast = () => useContext(T);

export function ToastProvider({ children }) {
  const [items, setItems] = useState([]);
  const push = useCallback((text, type = 'ok') => {
    const id = Math.random();
    setItems((a) => [...a, { id, text, type }]);
    setTimeout(() => setItems((a) => a.filter((x) => x.id !== id)), 3500);
  }, []);
  return (
    <T.Provider value={push}>
      {children}
      <div className="toasts" role="status" aria-live="polite">
        {items.map((i) => (
          <div key={i.id} className={`toast ${i.type}`}>{i.text}</div>
        ))}
      </div>
    </T.Provider>
  );
}
