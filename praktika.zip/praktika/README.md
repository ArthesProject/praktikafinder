# Practika.kg: поиск практик и стажировок (Бишкек)

React + Node.js (Express). Данные хранятся в server/db.json (без установки БД).

## Запуск
Терминал 1:
    cd server
    npm install
    npm start        # http://localhost:4000

Терминал 2:
    cd client
    npm install
    npm run dev      # http://localhost:5173  (открывать этот адрес)

Если уже был запуск старой версии: удалите server/db.json перед стартом,
тогда создадутся новые демо-данные (вакансии с направлениями, демо-компании).

Демо-аккаунты:
- Компания: company@demo.kg / 123456
- Студент: student@demo.kg / 123456
Остальные компании (Ala-Too Digital и т.д.) выдуманные, только для демонстрации.

## Что можно настроить
- client/src/siteConfig.js: контакты, соцсети и текст футера, список направлений
- client/public/images/: настоящие фото (hero.jpg, student-1..3.jpg), см. README.txt в папке

## API
POST /api/auth/register, POST /api/auth/login, GET /api/me, PUT /api/profile
GET /api/stats
GET /api/vacancies?q=&type=&category=, GET /api/vacancies/:id
POST /api/vacancies (компания), DELETE /api/vacancies/:id
POST /api/vacancies/:id/apply (студент)
GET /api/my/applications (студент), GET /api/my/vacancies (компания)
PATCH /api/applications/:id (компания: accepted/rejected)
