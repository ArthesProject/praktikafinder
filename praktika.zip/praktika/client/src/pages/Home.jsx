import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../auth.jsx';
import { HeroArt, Person, Photo } from '../components/Art.jsx';
import VacancyCard from '../components/VacancyCard.jsx';
import { categories } from '../siteConfig.js';

const QUOTES = [
  { name: 'Айдана', role: 'студентка, 3 курс', img: '/images/student-1.jpg', text: 'Вечером откликнулась на три вакансии, а утром мне уже написали из компании. Раньше на это уходила неделя.', person: { long: true, shirt: '#284b63', skin: '#e8b98f', bg: '#dff0f1' } },
  { name: 'Нурбек', role: 'студент, 2 курс', img: '/images/student-2.jpg', text: 'Указал в профиле навыки, и компания сама увидела, что я подхожу. Не пришлось рассылать резюме.', person: { shirt: '#0e7c86', skin: '#ddaa80', bg: '#fbefc9' } },
  { name: 'Элина', role: 'HR в IT-компании', img: '/images/student-3.jpg', text: 'Студенты приходят с готовыми профилями. Отклики собраны в одном месте, не нужно искать их по чатам.', person: { long: true, shirt: '#a8432f', skin: '#ecc19a', bg: '#e8eef0', ornament: true } },
];

const FAQ = [
  ['Сколько это стоит?', 'Сейчас сервис бесплатен и для студентов, и для компаний.'],
  ['Нужно ли резюме?', 'Достаточно заполнить профиль: университет, навыки и пара слов о себе. Компания увидит его вместе с вашим откликом.'],
  ['Как компании разместить вакансию?', 'Зарегистрируйтесь как компания, откройте «Кабинет компании» и нажмите «Новая вакансия».'],
  ['Как узнать результат отклика?', 'Статус отклика виден в разделе «Мои отклики»: на рассмотрении, принят или отказ.'],
  ['Можно ли откликнуться на несколько вакансий?', 'Да. На каждую вакансию можно откликнуться один раз.'],
];

export default function Home() {
  const { user } = useAuth();
  const [q, setQ] = useState('');
  const [type, setType] = useState('');
  const [cat, setCat] = useState('');
  const [list, setList] = useState(null);
  const [stats, setStats] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => { api('/stats').then(setStats).catch(() => {}); }, []);

  useEffect(() => {
    const t = setTimeout(() => {
      const qs = new URLSearchParams({ q, type, category: cat });
      api(`/vacancies?${qs}`).then(setList).catch((e) => setError(e.message));
    }, 250);
    return () => clearTimeout(t);
  }, [q, type, cat]);

  const goList = (e) => {
    e?.preventDefault();
    document.getElementById('vacancies')?.scrollIntoView({ behavior: 'smooth' });
  };

  const isStudent = user.role === 'student';

  return (
    <>
      <section className="hero">
        <div className="hero-copy">
          <h1>Найдите практику в Бишкеке и начните карьеру уже сейчас</h1>
          <p className="lead">Компании города ищут студентов. Выберите вакансию, откликнитесь за пару минут и следите за ответом.</p>
          <form className="hero-search" onSubmit={goList}>
            <input placeholder="Профессия, компания или навык: React, SQL, Figma" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Поиск вакансий" />
            <button className="btn">Найти</button>
          </form>
        </div>
        <Photo src="/images/hero.jpg" alt="Студенты в Бишкеке" className="hero-art"><HeroArt /></Photo>
      </section>

      {stats && (
        <section className="stats" aria-label="Статистика сервиса">
          {[['vacancies', 'вакансий'], ['companies', 'компаний'], ['students', 'студентов'], ['applications', 'откликов']].map(([k, l]) => (
            <div key={k}><strong>{stats[k]}</strong><span>{l}</span></div>
          ))}
        </section>
      )}

      <section className="section" id="vacancies">
        <h2>Свежие вакансии</h2>
        <p className="sub">Выберите направление или воспользуйтесь поиском выше.</p>
        <div className="filters">
          <div className="chips">
            {['', ...categories].map((c) => (
              <button key={c || 'all'} className={`chip ${cat === c ? 'on' : ''}`} onClick={() => setCat(c)}>{c || 'Все направления'}</button>
            ))}
          </div>
          <select value={type} onChange={(e) => setType(e.target.value)} aria-label="Тип">
            <option value="">Практика и стажировка</option>
            <option>Стажировка</option>
            <option>Практика</option>
          </select>
        </div>

        {error && <p className="error">{error}</p>}
        <div className="vgrid">
          {!list && !error && [0, 1, 2, 3].map((i) => <div key={i} className="skel" />)}
          {list?.map((v) => <VacancyCard key={v.id} v={v} />)}
        </div>
        {list?.length === 0 && (
          <div className="empty">
            <p><strong>Ничего не нашлось</strong></p>
            <p className="muted">Попробуйте другое направление или уберите часть слов из запроса.</p>
            <button className="btn small ghost" onClick={() => { setQ(''); setCat(''); setType(''); }}>Сбросить фильтры</button>
          </div>
        )}
      </section>

      <section className="section">
        <h2>Как это работает</h2>
        <p className="sub">Три шага от профиля до первого собеседования.</p>
        <div className="steps">
          <div className="step"><span className="num">1</span><h3>Заполните профиль</h3><p>Университет, навыки и коротко о себе. Это ваше резюме на сайте.</p></div>
          <div className="step"><span className="num">2</span><h3>Откликнитесь</h3><p>Выберите вакансию и напишите пару строк, почему она вам подходит.</p></div>
          <div className="step"><span className="num">3</span><h3>Получите ответ</h3><p>Компания принимает или отклоняет отклик, статус виден в вашем кабинете.</p></div>
        </div>
      </section>

      <section className="section">
        <h2>Что говорят пользователи</h2>
        <p className="sub">Примеры отзывов для демонстрации сайта.</p>
        <div className="quotes">
          {QUOTES.map((x) => (
            <figure key={x.name} className="quote">
              <blockquote>{x.text}</blockquote>
              <figcaption className="who">
                <Photo src={x.img} alt={x.name} className="avatar"><Person {...x.person} /></Photo>
                <span><strong>{x.name}</strong><br /><span className="muted small">{x.role}</span></span>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      <section className="section faq">
        <h2>Частые вопросы</h2>
        <p className="sub">Если не нашли ответ, напишите нам: контакты внизу страницы.</p>
        {FAQ.map(([qq, a]) => (
          <details key={qq}><summary>{qq}</summary><p>{a}</p></details>
        ))}
      </section>

      <section className="cta">
        <div>
          <h2>{isStudent ? 'Пусть компании вас заметят' : 'Найдите своего стажёра'}</h2>
          <p>{isStudent ? 'Добавьте навыки в профиль: компании увидят их вместе с откликом.' : 'Опубликуйте вакансию, и студенты Бишкека смогут откликнуться уже сегодня.'}</p>
        </div>
        <Link to={isStudent ? '/profile' : '/dashboard/new'} className="btn light">{isStudent ? 'Заполнить профиль' : 'Создать вакансию'}</Link>
      </section>
    </>
  );
}
