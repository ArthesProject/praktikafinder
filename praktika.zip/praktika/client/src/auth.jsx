import { createContext, useContext, useEffect, useState } from 'react';
import { api, getToken } from './api.js';

const Ctx = createContext(null);
export const useAuth = () => useContext(Ctx);

const clearToken = () => {
  localStorage.removeItem('token');
  sessionStorage.removeItem('token');
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(false);

  // при открытии сайта пробуем восстановить сессию по сохранённому токену
  useEffect(() => {
    if (!getToken()) return setReady(true);
    api('/me').then(setUser).catch(clearToken).finally(() => setReady(true));
  }, []);

  const authed = ({ token, user }, remember) => {
    clearToken();
    (remember ? localStorage : sessionStorage).setItem('token', token);
    setUser(user);
  };
  const login = async (email, password, remember = true) =>
    authed(await api('/auth/login', { method: 'POST', body: { email, password } }), remember);
  const register = async (data, remember = true) =>
    authed(await api('/auth/register', { method: 'POST', body: data }), remember);
  const logout = () => {
    clearToken();
    setUser(null);
  };

  return <Ctx.Provider value={{ user, setUser, ready, login, register, logout }}>{children}</Ctx.Provider>;
}
