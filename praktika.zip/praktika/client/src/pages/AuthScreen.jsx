import { useState } from 'react';
import { useAuth } from '../auth.jsx';
import { useToast } from '../components/Toast.jsx';
import { HeroArt, Mark, Photo } from '../components/Art.jsx';
import { site } from '../siteConfig.js';

export default function AuthScreen() {
  const { login, register } = useAuth();
  const toast = useToast();
  const [mode, setMode] = useState('login');
  const [f, setF] = useState({ role: 'student', name: '', email: '', password: '' });
  const [remember, setRemember] = useState(true);
  const [show, setShow] = useState(false);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });
  const isReg = mode === 'register';

  const submit = async (e) => {
    e.preventDefault();
    setError('');
    setBusy(true);
    try {
      if (isReg) await register(f, remember);
      else await login(f.email, f.password, remember);
      toast(isReg ? 'Аккаунт создан. Добро пожаловать!' : 'С возвращением!');
    } catch (err) {
      setError(err.message);
      setBusy(false);
    }
  };

  const demo = (role) => {
    setMode('login');
    setF({ ...f, email: role === 'student' ? 'student@demo.kg' : 'company@demo.kg', password: '123456' });
  };

  return (
    <div className="auth">
      <aside className="auth-side">
        <div className="logo"><Mark size={32} />{site.name}</div>
        <h1>{site.tagline}</h1>
        <ul>
          <li>Практики и стажировки в компаниях Бишкека</li>
          <li>Один профиль вместо десятков резюме</li>
          <li>Статус отклика виден сразу</li>
        </ul>
        <Photo src="/images/hero.jpg" alt="Студенты в Бишкеке" className="auth-art"><HeroArt /></Photo>
      </aside>

      <section className="auth-main">
        <form className="auth-card" onSubmit={submit}>
          <div className="tabs" role="tablist">
            <button type="button" role="tab" className={!isReg ? 'on' : ''} onClick={() => { setMode('login'); setError(''); }}>Вход</button>
            <button type="button" role="tab" className={isReg ? 'on' : ''} onClick={() => { setMode('register'); setError(''); }}>Регистрация</button>
          </div>

          {isReg && (
            <>
              <div className="seg">
                <button type="button" className={f.role === 'student' ? 'on' : ''} onClick={() => setF({ ...f, role: 'student' })}>Я студент</button>
                <button type="button" className={f.role === 'company' ? 'on' : ''} onClick={() => setF({ ...f, role: 'company' })}>Я компания</button>
              </div>
              <label>{f.role === 'company' ? 'Название компании' : 'Имя и фамилия'}
                <input value={f.name} onChange={set('name')} required autoComplete="name" />
              </label>
            </>
          )}

          <label>Email
            <input type="email" value={f.email} onChange={set('email')} required autoComplete="email" />
          </label>
          <label>Пароль
            <div className="pw">
              <input type={show ? 'text' : 'password'} value={f.password} onChange={set('password')} required minLength={6} autoComplete={isReg ? 'new-password' : 'current-password'} />
              <button type="button" className="link" onClick={() => setShow(!show)}>{show ? 'Скрыть' : 'Показать'}</button>
            </div>
          </label>

          <label className="check">
            <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} />
            Запомнить меня на этом устройстве
          </label>

          {error && <p className="error">{error}</p>}
          <button className="btn block" disabled={busy}>{busy ? 'Подождите…' : isReg ? 'Создать аккаунт' : 'Войти'}</button>

          <div className="demo">
            <span>Быстрый вход для демо:</span>
            <button type="button" className="link" onClick={() => demo('student')}>студент</button>
            <button type="button" className="link" onClick={() => demo('company')}>компания</button>
          </div>
        </form>
      </section>
    </div>
  );
}
