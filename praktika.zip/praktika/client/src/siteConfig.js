// Все тексты футера и контакты меняются здесь.
// Значения с "___" — заглушки, заменить на настоящие.
export const site = {
  name: 'Practika.kg',
  tagline: 'Первая практика — рядом с домом',
  about: 'Сервис, который помогает студентам Кыргызстана найти практику и стажировку, а компаниям — найти молодых специалистов.',
  city: 'Бишкек, Кыргызстан',
  email: 'hello@practika.kg',
  phone: '+996 (___) __-__-__',
  socials: [
    { label: 'Instagram', href: '#' },
    { label: 'Telegram', href: '#' },
    { label: 'LinkedIn', href: '#' },
  ],
  credit: 'Дипломный проект',
};

export const categories = ['Frontend', 'Backend', 'Дизайн', 'Маркетинг', 'Финансы', 'QA'];
