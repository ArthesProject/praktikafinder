import { useEffect } from 'react';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { useAuth } from './auth.jsx';
import Header from './components/Header.jsx';
import Footer from './components/Footer.jsx';
import { Mark } from './components/Art.jsx';
import AuthScreen from './pages/AuthScreen.jsx';
import Home from './pages/Home.jsx';
import Vacancy from './pages/Vacancy.jsx';
import Profile from './pages/Profile.jsx';
import MyApplications from './pages/MyApplications.jsx';
import Dashboard from './pages/Dashboard.jsx';
import NewVacancy from './pages/NewVacancy.jsx';

function Role({ role, children }) {
  const { user } = useAuth();
  return user.role === role ? children : <Navigate to="/" replace />;
}

export default function App() {
  const { user, ready } = useAuth();
  const { pathname } = useLocation();

  useEffect(() => { window.scrollTo(0, 0); }, [pathname]);

  if (!ready) return <div className="boot"><Mark size={44} /></div>;
  if (!user) return <AuthScreen />;

  return (
    <div className="shell">
      <Header />
      <main className="page" key={pathname}>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/vacancy/:id" element={<Vacancy />} />
          <Route path="/profile" element={<Profile />} />
          <Route path="/applications" element={<Role role="student"><MyApplications /></Role>} />
          <Route path="/dashboard" element={<Role role="company"><Dashboard /></Role>} />
          <Route path="/dashboard/new" element={<Role role="company"><NewVacancy /></Role>} />
          <Route path="/login" element={<Navigate to="/" replace />} />
          <Route path="/register" element={<Navigate to="/" replace />} />
          <Route path="*" element={<p>Страница не найдена</p>} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
}
