import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';
import { STATUS } from './MyApplications.jsx';

export default function Dashboard() {
  const [list, setList] = useState(null);
  const reload = () => api('/my/vacancies').then(setList);
  useEffect(() => { reload(); }, []);

  const setStatus = async (id, status) => { await api(`/applications/${id}`, { method: 'PATCH', body: { status } }); reload(); };
  const remove = async (id) => {
    if (!confirm('Удалить вакансию вместе с откликами?')) return;
    await api(`/vacancies/${id}`, { method: 'DELETE' });
    reload();
  };

  if (!list) return <p className="muted">Загрузка…</p>;
  return (
    <>
      <div className="row">
        <h1>Кабинет компании</h1>
        <Link to="/dashboard/new" className="btn">Новая вакансия</Link>
      </div>
      {list.length === 0 && <p className="muted">Вакансий пока нет. Создайте первую — студенты увидят её на главной.</p>}
      <div className="list">
        {list.map((v) => (
          <div key={v.id} className="card">
            <div className="row">
              <h3><Link to={`/vacancy/${v.id}`}>{v.title}</Link></h3>
              <button className="link danger" onClick={() => remove(v.id)}>Удалить</button>
            </div>
            <p className="muted">{v.type} · {v.format} · откликов: {v.applications.length}</p>
            {v.applications.map((a) => (
              <div key={a.id} className="app">
                <div className="row">
                  <strong>{a.student?.name}</strong>
                  <span className={`tag ${a.status}`}>{STATUS[a.status]}</span>
                </div>
                <p className="muted">{a.student?.email}{a.student?.university ? ` · ${a.student.university}` : ''}</p>
                {a.student?.skills && <p>Навыки: {a.student.skills}</p>}
                {a.message && <p className="pre">«{a.message}»</p>}
                <div className="actions">
                  <button className="btn small" onClick={() => setStatus(a.id, 'accepted')}>Принять</button>
                  <button className="btn small ghost" onClick={() => setStatus(a.id, 'rejected')}>Отказать</button>
                </div>
              </div>
            ))}
          </div>
        ))}
      </div>
    </>
  );
}
